import React from 'react'

const Footer = () => {
  return (
    <div>
        <footer>
           <h1>Bye bye buuterfly</h1> 
        </footer>
    </div>
  )
}

export default Footer