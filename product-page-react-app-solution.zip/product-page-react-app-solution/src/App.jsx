import "./App.css";
import HeroSection from "./components/Hero";
import Navigation from "./components/Navigation";
import Footer from "./components/Footer";
const App = () => {
  return (
    <div>
      <Navigation />
      <HeroSection />
      <Footer />
    </div>
  );
};

export default App;
